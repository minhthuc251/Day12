//
//  FlyBird.m
//  UIViewControls
//
//  Created by techmaster on 9/19/14.
//  Copyright (c) 2014 Techmaster. All rights reserved.
//

#import "FlyBird.h"

@interface FlyBird ()

@end

@implementation FlyBird

- (void)viewDidLoad {
    [super viewDidLoad];

}

- (void) flyABird {
    
}

@end
